/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cliente;

import java.util.ArrayList;

import Produtos.Box;
import Produtos.Produto;


/**
 *
 * @author Jéssica Ferreira
 */
public class Cliente {
    
    private  String plano;
    private  int qtdItens;
    private  Box caixa =  new  Box ();
    
    public  Cliente ( String  plano , int  qtdItens ) {
       this.plano = plano;
       this.qtdItens = qtdItens;                
    }
    

    public  String  getPlano () {
        return plano;
    }

    public  int  getQtdItens () {
        return qtdItens;
    }
    
    public void setBox(Box box)
    {
    	this.caixa = box;
    }

    public  Box  getBox () {
        return this.caixa;
    }
    
    
}
