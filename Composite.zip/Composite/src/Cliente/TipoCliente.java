/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cliente;

/**
 *
 * @author Jéssica Ferreira
 */
public enum TipoCliente {
    
    BRONZE (new  Cliente ("Bronze" , 3 )),
    PRATA (new  Cliente (" Prata " , 5 )),
    OURO (new Cliente ("Ouro" ,7 )),
    PLATINA ( new  Cliente ( " Platina " , 10 ));
    
    private Cliente cliente ;
    
    TipoCliente ( Cliente  cliente ) {
        this. cliente = cliente;
    };

    
    

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    
}
