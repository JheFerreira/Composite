/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produtos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Consumer;

import Cliente.Cliente;

/**
 *
 * @author Jéssica Ferreira
 */
public class Box implements  Composite {

    private  ArrayList <Composite > children =  new  ArrayList <> ();
    
    
   //metodo preço inicializando em zero
    public  double  getPrice () {
        double soma =  0;
   //para os itens criados, somar os itens e preços    
       
   for (Composite itens :  this.children) {            
            soma  += itens.getPrice();            
        }
        
        return soma;
    }
    
    public  void  abrirBox () {
        
    	for (Composite item :  this.children) 
        {    
    // se o item da classe for igual ao produto        
            if (item.getClass ().equals ( Produto.class)) 
            {            	
    
    // produto recebe o item            
                Produto produto = (Produto) item;
                
    //imprime o nome e o valor do produto            
                System.out.println ("\nItem:"  + produto.getName() + "\n Valor: R$ " +produto.getPrice());
            }
        }
    }
    
    public  void  add ( Composite itens  ) {
        this.children.add((Produto) itens);                     
    }    
   
	public  void  remove ( ArrayList < Composite > itens  ) {       
        this.children.removeAll(itens);
    }

 
    public  void  setChildren ( ArrayList < Composite >  children ) {        
        this.children = children;        
    }
}
