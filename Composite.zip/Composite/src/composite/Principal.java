/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package composite;

import Cliente.Cliente;
import Cliente.TipoCliente;
import  java.util.ArrayList ;
import  java.util.Random ;

import Produtos.Box;
import Produtos.Composite;
import  Produtos.Produto ;
import java.util.function.Consumer;
/**
 *
 * @author Jéssica Ferreira
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList < Produto > produtos =  new  ArrayList <> ();       
        ArrayList < Cliente > clientes =  new  ArrayList <> ();        
        
        // tipos de clientes
        clientes.add(TipoCliente.BRONZE.getCliente());
        clientes.add(TipoCliente.PRATA.getCliente());
        clientes.add(TipoCliente.OURO.getCliente());
        clientes.add(TipoCliente.PLATINA.getCliente());  
        
        // cria produtos
        produtos.add(new Produto ( " Quadrinhos " , 15 ));
        produtos.add(new Produto (" Chaveiros " , 5 ));
        produtos.add(new Produto  ( " Bustos " , 10 ));
        produtos.add(new Produto ( " Adesivos " , 1 ));
        produtos.add(new Produto ( " Posters " , 25 ));
        produtos.add(new Produto ( " Camisetas " , 25 ));
        produtos.add(new Produto ( " Miniaturas " , 20 ));
        
        // saida
        for (Cliente cliente :  clientes)
        {
        	System.out.println( " ---------------------------------------- " );
        	System.out.println ( " ---------------------------------------- " );        
        	System.out.println ( " Cliente Nível: "  + cliente.getPlano());      
               
        	// Cria um novo box
        	System.out.println ( " Criando box para o cliente com " + cliente.getQtdItens () + " itens " );
        	Box nova_caixa = escolherItensBox(cliente.getQtdItens (), produtos);
        	
        	// Atrela esse box ao cliente
        	cliente.setBox(nova_caixa);
        
            // Abre o box
        	System.out.println ( " Abrindo box para visualizar a coleção. " );
            cliente.getBox ().abrirBox ();
            
            System.out.println("");
            System.out.println( "Valor total do box: "  + cliente.getBox ().getPrice ());
            System.out.println( " ----------------------------------------" );
            // });         
        }           
    }
    
    
    // gerador ramdomico para escolha de itens    
        private  static  Box escolherItensBox ( int  numeroItens , ArrayList  produtos ) {
    	
    	// Cria lista de produtos temporária
    	ArrayList<Composite> prod_aleatorios = new  ArrayList <> ();
    	
    	// para a quantidade de itens, roda o loop
    	for(int i = 0; i < numeroItens; i++)
    	{
    		// gera um índice aleatório 
    		int index = (int)(Math.random() * produtos.size());  
    		
    		// adiciona em uma lista de produtos temporária
    		prod_aleatorios.add((Produto) produtos.get(index));
    	}
    	
    	// cria o box
    	Box box = new Box();
    	
    	// alimenta ele com os produtos gerados aleatoriamente da lista temporária
    	box.setChildren(prod_aleatorios);
    	
    	// retorna o box pronto
    	return box;
    }
    
    
}
